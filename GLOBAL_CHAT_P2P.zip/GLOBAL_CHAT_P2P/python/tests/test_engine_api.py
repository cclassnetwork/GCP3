import asyncio, json, os, socket, sys, time
import pytest
from helpers import run, until, make_node, stop_all
from gcp2p.engine import Engine, EngineError, parse_peer_address
from gcp2p.api.server import ApiServer
from gcp2p.discovery.lan import make_beacon, parse_beacon, LanDiscovery
from gcp2p.identity.identity import Identity


async def http(port, method, path, body=None, token="tok", host="127.0.0.1"):
    r, w = await asyncio.open_connection("127.0.0.1", port)
    data = json.dumps(body).encode() if body is not None else b""
    hdr = f"{method} {path} HTTP/1.1\r\nHost: {host}:{port}\r\nContent-Length: {len(data)}\r\n"
    if token is not None:
        hdr += f"X-GC-Token: {token}\r\n"
    w.write(hdr.encode() + b"\r\n" + data); await w.drain()
    raw = await r.read(-1); w.close()
    head, _, payload = raw.partition(b"\r\n\r\n")
    status = int(head.split()[1])
    return status, (json.loads(payload) if payload else None)


async def boot(tmp, name, **kw):
    eng = Engine(str(tmp / name), host="127.0.0.1", **kw)
    await eng.start()
    api = ApiServer(eng, "tok"); port = await api.start()
    for t in (0,):
        pass
    return eng, api, port


def test_api_requires_token_and_loopback_host(tmp_path):
    async def go():
        eng, api, port = await boot(tmp_path, "a")
        assert (await http(port, "GET", "/api/state", token=None))[0] == 401
        assert (await http(port, "GET", "/api/state", token="wrong"))[0] == 401
        assert (await http(port, "GET", "/api/state", host="evil.example"))[0] == 403
        st, body = await http(port, "GET", "/api/state")
        assert st == 200 and body == {"has_identity": False}
        assert (await http(port, "GET", "/api/nope"))[0] == 404
        await api.stop(); await eng.stop()
    run(go())


def test_identity_creation_username_change_and_encrypted_storage(tmp_path):
    async def go():
        eng, api, port = await boot(tmp_path, "a")
        assert (await http(port, "POST", "/api/identity/create", {"username": "x"}))[0] == 400
        st, s = await http(port, "POST", "/api/identity/create", {})        # step 1: anonymous identity, no name needed
        assert st == 200 and s["has_identity"] and s["username"] == "user" + s["peer_id"][-4:]
        pid = s["peer_id"]
        st, s = await http(port, "POST", "/api/username", {"username": "Sani_01"})   # step 2: choose a username
        assert s["username"] == "Sani_01" and s["peer_id"] == pid
        assert (await http(port, "POST", "/api/identity/create", {"username": "Again"}))[0] == 400
        st, s2 = await http(port, "POST", "/api/username", {"username": "Sani_New"})
        assert s2["username"] == "Sani_New" and s2["peer_id"] == pid
        assert (await http(port, "POST", "/api/username", {"username": "bad name!"}))[0] == 400
        raw_priv = eng.identity.to_bytes()
        blob = eng.db.get_identity_blob()
        assert raw_priv not in blob and raw_priv[:32] not in blob
        await api.stop(); await eng.stop()
        # restart: same identity, same username, same listening port
        eng2, api2, port2 = await boot(tmp_path, "a")
        st, s3 = await http(port2, "GET", "/api/state")
        assert s3["peer_id"] == pid and s3["username"] == "Sani_New"
        await api2.stop(); await eng2.stop()
        # identity cannot be opened with a different device key
        bad = Engine(str(tmp_path / "a"), storage_key=os.urandom(32))
        with pytest.raises(EngineError):
            await bad.start()
    run(go())


def test_two_engines_chat_through_api_and_events(tmp_path):
    async def go():
        a, apia, pa = await boot(tmp_path, "a", lan_port=47811)
        b, apib, pb = await boot(tmp_path, "b", lan_port=47812)
        await http(pa, "POST", "/api/identity/create", {"username": "alice"})
        await http(pb, "POST", "/api/identity/create", {"username": "bobby"})
        for e in (a, b):
            e.node.tick_seconds = 0.3
        # live events over SSE
        r, w = await asyncio.open_connection("127.0.0.1", pb)
        w.write(f"GET /api/events HTTP/1.1\r\nHost: 127.0.0.1:{pb}\r\nX-GC-Token: tok\r\n\r\n".encode()); await w.drain()
        await r.readuntil(b": connected\n\n")
        st, res = await http(pb, "POST", "/api/connect", {"addr": f"127.0.0.1:{a.node.port}"})
        assert res["connected"] is True
        assert await until(lambda: any(p["username"] == "alice" for p in b.peers()), 10)
        alice_id = a.identity.peer_id
        st, m = await http(pb, "POST", "/api/dm/send", {"to": alice_id, "text": "salaam"})
        assert st == 200 and m["status"] == "queued"
        assert await until(lambda: any(x["status"] == "delivered" for x in b.thread(alice_id)["messages"]), 10)
        st, t = await http(pa, "GET", f"/api/dm/{b.identity.peer_id}")
        assert [x["body"] for x in t["messages"]] == ["salaam"] and t["handle"].startswith("bobby#")
        st, c = await http(pa, "GET", "/api/conversations")
        assert c["conversations"][0]["unread"] == 1
        await http(pa, "POST", f"/api/dm/{b.identity.peer_id}/read", {})
        assert (await http(pa, "GET", "/api/conversations"))[1]["conversations"][0]["unread"] == 0
        await http(pb, "POST", "/api/group/send", {"text": "hello world"})
        assert await until(lambda: len(a.group_messages()) == 1, 10)
        st, g = await http(pa, "GET", "/api/group")
        assert g["messages"][0]["body"] == "hello world" and g["messages"][0]["mine"] is False
        st, net = await http(pa, "GET", "/api/network")
        assert net["connections"] == 1 and net["listening"] is True
        got = b""
        try:
            got = await asyncio.wait_for(r.read(4096), 3)
        except asyncio.TimeoutError:
            pass
        assert b'"type":"' in got
        w.close()
        # too long / empty messages are refused
        assert (await http(pb, "POST", "/api/group/send", {"text": "  "}))[0] == 400
        assert (await http(pb, "POST", "/api/dm/send", {"to": "nonsense", "text": "x"}))[0] == 400
        for x in (apia, apib): await x.stop()
        await a.stop(); await b.stop()
    run(go(), 60)


def test_settings_bootstrap_and_address_parsing(tmp_path):
    async def go():
        eng, api, port = await boot(tmp_path, "a")
        await http(port, "POST", "/api/identity/create", {"username": "alice"})
        st, s = await http(port, "POST", "/api/settings", {"relay": False, "store_forward": False, "evil": True, "lan": "yes"})
        assert s["relay"] is False and s["store_forward"] is False and "evil" not in s and s["lan"] is True
        assert eng.node.relay.enabled is False
        pid = Identity.generate().peer_id
        st, b = await http(port, "POST", "/api/bootstrap/add", {"addr": f"gcp2p://{pid}@203.0.113.5:4001"})
        assert b["bootstrap"] == [f"{pid}@203.0.113.5:4001"]
        assert (await http(port, "POST", "/api/bootstrap/add", {"addr": "not an address"}))[0] == 400
        assert (await http(port, "POST", "/api/bootstrap/add", {"addr": "host:99999"}))[0] == 400
        st, b = await http(port, "POST", "/api/bootstrap/remove", {"addr": f"{pid}@203.0.113.5:4001"})
        assert b["bootstrap"] == []
        assert (await http(port, "POST", "/api/identity/reset", {}))[0] == 400            # needs confirmation
        st, _ = await http(port, "POST", "/api/identity/reset", {"confirm": "DELETE"})
        assert (await http(port, "GET", "/api/state"))[1] == {"has_identity": False}
        await api.stop(); await eng.stop()
    run(go())
    assert parse_peer_address("example.org:4001") == "example.org:4001"


def test_lan_beacons_signed_and_discovery_works():
    me = Identity.generate(); now = time.time()
    data = make_beacon(me, 4001, now)
    assert parse_beacon(data, now) == (me.peer_id, 4001)
    assert parse_beacon(data, now + 500) is None                    # stale
    tampered = json.loads(data); tampered["port"] = 9; assert parse_beacon(json.dumps(tampered).encode(), now) is None
    assert parse_beacon(b"junk", now) is None

    async def go():
        a, b = await make_node("alice"), await make_node("bobby")
        pa, pb = 47821, 47822
        a.lan = LanDiscovery(a, bind_port=pa, targets=[("127.0.0.1", pb)])
        b.lan = LanDiscovery(b, bind_port=pb, targets=[("127.0.0.1", pa)])
        await a.lan.start(); await b.lan.start()
        assert await until(lambda: b.id in a.conns and a.id in b.conns, 10)
        await stop_all(a, b)
    run(go())


def test_android_entry_point_starts_engine_and_serves_api(tmp_path):
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
    import gc_android
    ep = gc_android.start(str(tmp_path / "droid"), os.urandom(32).hex(), None)
    port, token = ep.split(":")

    async def go():
        st, body = await http(int(port), "GET", "/api/state", token=token)
        assert st == 200 and body == {"has_identity": False}
        st, body = await http(int(port), "POST", "/api/identity/create", {"username": "phone_user"}, token=token)
        assert st == 200 and body["has_identity"]
    run(go())
    assert gc_android.start(str(tmp_path / "droid"), "", None) == ep           # idempotent
    gc_android.kick()
    gc_android.stop()
