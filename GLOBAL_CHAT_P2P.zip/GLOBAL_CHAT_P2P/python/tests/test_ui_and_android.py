"""UI serving + static checks of the Android project (the APK itself can only be built by GitHub Actions)."""
import asyncio, os, re, xml.etree.ElementTree as ET
from helpers import run
from gcp2p.engine import Engine
from gcp2p.api.server import ApiServer, WEB_DIR

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
TOKEN = "ab" * 16


async def raw_get(port, path, host="127.0.0.1", headers=""):
    r, w = await asyncio.open_connection("127.0.0.1", port)
    w.write(f"GET {path} HTTP/1.1\r\nHost: {host}:{port}\r\n{headers}\r\n".encode()); await w.drain()
    data = await r.read(-1); w.close()
    head, _, body = data.partition(b"\r\n\r\n")
    return int(head.split()[1]), head.decode("latin-1").lower(), body


def test_ui_is_served_only_with_the_secret_token_and_strict_csp(tmp_path):
    async def go():
        eng = Engine(str(tmp_path / "e"), host="127.0.0.1"); await eng.start()
        api = ApiServer(eng, TOKEN); port = await api.start()
        st, head, body = await raw_get(port, f"/ui/{TOKEN}/")
        assert st == 200 and b"<title>Global Chat P2P</title>" in body
        assert "content-security-policy" in head and "script-src 'self'" in head and "'unsafe-inline'" not in head
        assert "unsafe-eval" not in head and "no-referrer" in head
        for name, mime in (("app.js", "javascript"), ("app.css", "text/css")):
            st, head, body = await raw_get(port, f"/ui/{TOKEN}/{name}")
            assert st == 200 and mime in head and len(body) > 1000
        assert (await raw_get(port, f"/ui/{'0' * 32}/"))[0] == 401          # wrong token
        assert (await raw_get(port, "/ui/"))[0] in (401, 404)               # no token
        assert (await raw_get(port, f"/ui/{TOKEN}/..%2fengine.py"))[0] in (401, 404)   # no path traversal
        assert (await raw_get(port, f"/ui/{TOKEN}/engine.py"))[0] == 404          # only web assets
        assert (await raw_get(port, f"/ui/{TOKEN}/", host="evil.example"))[0] == 403   # DNS-rebinding guard
        await api.stop(); await eng.stop()
    run(go(), 30)


def test_web_files_have_no_external_requests_or_inline_script():
    for name in os.listdir(WEB_DIR):
        text = open(os.path.join(WEB_DIR, name), encoding="utf-8").read()
        assert not re.search(r"""(?:src|href)\s*=\s*["']https?://""", text), name
        assert "eval(" not in text and "innerHTML = location" not in text, name
    html = open(os.path.join(WEB_DIR, "index.html"), encoding="utf-8").read()
    assert not re.search(r"<script(?![^>]*\bsrc=)", html), "inline <script> would be blocked by the CSP"
    assert " style=" not in html


def test_android_project_is_consistent():
    a = os.path.join(ROOT, "android")
    man = open(os.path.join(a, "app/src/main/AndroidManifest.xml"), encoding="utf-8").read()
    ET.fromstring(man)
    perms = set(re.findall(r'uses-permission android:name="android.permission.([A-Z_]+)"', man))
    assert perms == {"INTERNET", "ACCESS_NETWORK_STATE", "CHANGE_WIFI_MULTICAST_STATE", "POST_NOTIFICATIONS",
                     "FOREGROUND_SERVICE", "FOREGROUND_SERVICE_SPECIAL_USE"}, perms      # only what is needed
    assert 'allowBackup="false"' in man and 'usesCleartextTraffic="false"' in man
    nsc = open(os.path.join(a, "app/src/main/res/xml/network_security_config.xml"), encoding="utf-8").read()
    ET.fromstring(nsc)
    assert nsc.count('cleartextTrafficPermitted="true"') == 1 and "127.0.0.1" in nsc
    java = os.path.join(a, "app/src/main/java/net/globalchat/p2p")
    for cls in re.findall(r'android:name="\.(\w+)"', man):
        assert os.path.exists(os.path.join(java, cls + ".java")), cls
    gradle = open(os.path.join(a, "app/build.gradle.kts"), encoding="utf-8").read()
    assert 'extractPackages("gcp2p")' in gradle and 'version = "3.12"' in gradle and "net.globalchat.p2p" in gradle
    assert open(os.path.join(a, "app/requirements-android.txt")).read().split() == ["cryptography==42.0.8"]
    for sz in ("mdpi", "hdpi", "xhdpi", "xxhdpi", "xxxhdpi"):
        assert os.path.exists(os.path.join(a, f"app/src/main/res/mipmap-{sz}/ic_launcher.png"))
    # every engine module imports only the standard library or cryptography (what the phone build installs)
    std = set(__import__("sys").stdlib_module_names)
    for dp, _, fs in os.walk(os.path.join(ROOT, "python", "gcp2p")):
        for f in fs:
            if not f.endswith(".py"):
                continue
            for m in re.findall(r"^(?:from|import)\s+([A-Za-z_][\w]*)", open(os.path.join(dp, f), encoding="utf-8").read(), re.M):
                assert m in std or m in ("cryptography", "gcp2p", "__future__"), (f, m)


def test_java_calls_the_python_entry_points_that_exist():
    java = open(os.path.join(ROOT, "android/app/src/main/java/net/globalchat/p2p/MainActivity.java"), encoding="utf-8").read()
    py = open(os.path.join(ROOT, "python/gc_android.py"), encoding="utf-8").read()
    for fn in set(re.findall(r'callAttr\("(\w+)"', java)):
        assert re.search(rf"^def {fn}\(", py, re.M), fn
    notifier = open(os.path.join(ROOT, "android/app/src/main/java/net/globalchat/p2p/Notifier.java"), encoding="utf-8").read()
    assert "public void onMessage(String peer, String name, String text, boolean priv)" in notifier
    assert "notifier.onMessage(" in py
