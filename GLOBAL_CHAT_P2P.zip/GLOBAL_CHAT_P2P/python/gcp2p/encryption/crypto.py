"""Cryptographic primitives for GLOBAL CHAT P2P.

Only primitives from the widely reviewed `cryptography` package are used:
Ed25519 (identity / signatures), X25519 (key agreement), HKDF-SHA256,
ChaCha20-Poly1305 (AEAD).  No home-made cryptography.

NOTE: the *protocol* built from these primitives has NOT had an independent
security review.  See docs/SECURITY.md.
"""
from __future__ import annotations

import base64
import hashlib
import json
import os
import re

from cryptography.exceptions import InvalidSignature, InvalidTag
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from cryptography.hazmat.primitives.asymmetric.x25519 import (
    X25519PrivateKey,
    X25519PublicKey,
)
from cryptography.hazmat.primitives.ciphers.aead import ChaCha20Poly1305
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat

PEER_ID_RE = re.compile(r"^gc[a-z2-7]{32}$")


class CryptoError(Exception):
    pass


def b64e(b: bytes) -> str:
    return base64.b64encode(b).decode("ascii")


def b64d(s: str) -> bytes:
    if not isinstance(s, str):
        raise CryptoError("expected base64 string")
    try:
        return base64.b64decode(s.encode("ascii"), validate=True)
    except Exception as exc:  # binascii.Error, UnicodeError
        raise CryptoError("bad base64") from exc


def canonical(obj) -> bytes:
    """Deterministic JSON encoding used for everything that is signed."""
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def sha256(data: bytes) -> bytes:
    return hashlib.sha256(data).digest()


def peer_id_from_pub(pub: bytes) -> str:
    """Permanent peer ID = 'gc' + base32(first 160 bits of SHA-256(public key))."""
    return "gc" + base64.b32encode(sha256(pub)[:20]).decode("ascii").lower().rstrip("=")


def valid_peer_id(value) -> bool:
    return isinstance(value, str) and bool(PEER_ID_RE.match(value))


def node_id(peer_id: str) -> int:
    """Position of a peer in the Kademlia XOR key space."""
    return int.from_bytes(sha256(peer_id.encode("ascii")), "big")


def key_id(kind: str, ident: str) -> int:
    """Key-space position of a stored record (e.g. 'presence', peer id)."""
    return int.from_bytes(sha256(f"{kind}|{ident}".encode("utf-8")), "big")


def verify(pub: bytes, sig: bytes, data: bytes) -> bool:
    try:
        Ed25519PublicKey.from_public_bytes(pub).verify(sig, data)
        return True
    except (InvalidSignature, ValueError):
        return False


def x25519_pub_bytes(sk: X25519PrivateKey) -> bytes:
    return sk.public_key().public_bytes(Encoding.Raw, PublicFormat.Raw)


def hkdf(secret: bytes, salt: bytes, info: bytes, length: int = 32) -> bytes:
    return HKDF(algorithm=hashes.SHA256(), length=length, salt=salt, info=info).derive(secret)


def ecdh(sk: X25519PrivateKey, peer_pub: bytes) -> bytes:
    try:
        return sk.exchange(X25519PublicKey.from_public_bytes(peer_pub))
    except ValueError as exc:  # invalid / low-order point
        raise CryptoError("bad key agreement") from exc


# ---- end-to-end sealed boxes (direct messages) -----------------------------

def seal(recipient_xpk: bytes, plaintext: bytes, aad: bytes) -> dict:
    """Encrypt to a recipient's X25519 key using a fresh ephemeral key.

    Confidentiality + integrity for the recipient.  The sender is
    authenticated by an Ed25519 signature *inside* the plaintext.
    """
    esk = X25519PrivateKey.generate()
    epk = x25519_pub_bytes(esk)
    key = hkdf(ecdh(esk, recipient_xpk), salt=epk + recipient_xpk, info=b"gcp2p-dm-v1")
    nonce = os.urandom(12)
    ct = ChaCha20Poly1305(key).encrypt(nonce, plaintext, aad)
    return {"epk": b64e(epk), "n": b64e(nonce), "c": b64e(ct)}


def unseal(xsk: X25519PrivateKey, my_xpk: bytes, env: dict, aad: bytes) -> bytes:
    try:
        epk = b64d(env["epk"])
        nonce = b64d(env["n"])
        ct = b64d(env["c"])
    except (KeyError, TypeError) as exc:
        raise CryptoError("malformed envelope") from exc
    if len(epk) != 32 or len(nonce) != 12:
        raise CryptoError("malformed envelope")
    key = hkdf(ecdh(xsk, epk), salt=epk + my_xpk, info=b"gcp2p-dm-v1")
    try:
        return ChaCha20Poly1305(key).decrypt(nonce, ct, aad)
    except InvalidTag as exc:
        raise CryptoError("decryption failed") from exc


# ---- at-rest wrapping of the identity key ---------------------------------

def wrap(storage_key: bytes, data: bytes, label: bytes) -> bytes:
    if len(storage_key) != 32:
        raise CryptoError("storage key must be 32 bytes")
    nonce = os.urandom(12)
    return nonce + ChaCha20Poly1305(storage_key).encrypt(nonce, data, label)


def unwrap(storage_key: bytes, blob: bytes, label: bytes) -> bytes:
    if len(storage_key) != 32 or len(blob) < 28:
        raise CryptoError("bad wrapped blob")
    try:
        return ChaCha20Poly1305(storage_key).decrypt(blob[:12], blob[12:], label)
    except InvalidTag as exc:
        raise CryptoError("wrong storage key or corrupted data") from exc
