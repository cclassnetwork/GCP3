"""Anonymous cryptographic identity.

A user is an Ed25519 key pair (signatures) plus an X25519 key pair
(encryption).  The permanent peer ID is derived from the Ed25519 public
key only, so it never changes.  The username is just a signed label.
"""
from __future__ import annotations

import re

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey
from cryptography.hazmat.primitives.serialization import (
    Encoding,
    NoEncryption,
    PrivateFormat,
    PublicFormat,
)

from ..encryption import crypto

USERNAME_RE = re.compile(r"^[A-Za-z0-9_.\-]{3,24}$")


class IdentityError(Exception):
    pass


def validate_username(name) -> str:
    if not isinstance(name, str):
        raise IdentityError("Username must be text.")
    name = name.strip()
    if not USERNAME_RE.match(name):
        raise IdentityError("Username must be 3-24 characters: letters, digits, _ . -")
    return name


def handle(username: str, peer_id: str) -> str:
    """Display form.  Usernames are NOT unique in a decentralized network, so
    the last characters of the peer ID are always shown to tell people apart."""
    return f"{username}#{peer_id[-4:]}"


class Identity:
    def __init__(self, ed_sk: Ed25519PrivateKey, x_sk: X25519PrivateKey):
        self._ed = ed_sk
        self.x_sk = x_sk
        self.pub = ed_sk.public_key().public_bytes(Encoding.Raw, PublicFormat.Raw)
        self.xpub = crypto.x25519_pub_bytes(x_sk)
        self.peer_id = crypto.peer_id_from_pub(self.pub)

    @classmethod
    def generate(cls) -> "Identity":
        return cls(Ed25519PrivateKey.generate(), X25519PrivateKey.generate())

    @classmethod
    def from_bytes(cls, raw: bytes) -> "Identity":
        if len(raw) != 64:
            raise IdentityError("corrupt identity")
        return cls(
            Ed25519PrivateKey.from_private_bytes(raw[:32]),
            X25519PrivateKey.from_private_bytes(raw[32:]),
        )

    def to_bytes(self) -> bytes:
        ed = self._ed.private_bytes(Encoding.Raw, PrivateFormat.Raw, NoEncryption())
        x = self.x_sk.private_bytes(Encoding.Raw, PrivateFormat.Raw, NoEncryption())
        return ed + x

    def sign(self, data: bytes) -> bytes:
        return self._ed.sign(data)

    def fingerprint(self) -> str:
        """Human-comparable fingerprint (for verifying a contact out of band)."""
        h = crypto.sha256(self.pub).hex()[:32].upper()
        return " ".join(h[i : i + 4] for i in range(0, 32, 4))


def fingerprint_of(pub: bytes) -> str:
    h = crypto.sha256(pub).hex()[:32].upper()
    return " ".join(h[i : i + 4] for i in range(0, 32, 4))
