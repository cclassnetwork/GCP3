plugins {
    id("com.android.application")
    id("com.chaquo.python")
}

android {
    namespace = "net.globalchat.p2p"
    compileSdk = 34

    defaultConfig {
        applicationId = "net.globalchat.p2p"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        ndk {
            // 64-bit phones (almost every phone since 2018). Add "x86_64" to also run on an emulator.
            abiFilters += listOf("arm64-v8a")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

chaquopy {
    defaultConfig {
        version = "3.12"
        pip {
            install("-r", "requirements-android.txt")
        }
        // The engine serves its web screens from files next to its code, so it must be unpacked, not zipped.
        extractPackages("gcp2p")
    }
}
// The Python engine (python/gcp2p and gc_android.py) is copied into src/main/python by ../prepare.sh before the build.
