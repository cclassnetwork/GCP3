# Build the APK (phone only, GitHub Actions)

1. In GitHub create a **new** repository (for example `GCP2P`). Do not reuse the CCLASS one.
2. *Add file -> Upload files*: upload `GLOBAL_CHAT_P2P.zip` (the zip itself, not unzipped). Commit.
3. *Add file -> Create new file*, name it `.github/workflows/android.yml` (typing the slashes creates the folders),
   paste the contents of `android_globalchat.yml`, commit.
4. Open the **Actions** tab. If a run does not start, choose *Global Chat APK -> Run workflow*. Wait about 10-15 minutes.
5. Open the finished run, scroll to **Artifacts**, download `globalchat-apk` (a zip), unzip it, install the `.apk`
   (allow "install unknown apps" for your browser/file manager).

If you change the zip later, upload the new one and start a **new** run (re-running an old run builds the old commit).

## Debug vs release
The workflow builds the *debug* APK (fine to install and test). A *release* build needs your own signing key:

    keytool -genkeypair -v -keystore gcp2p.jks -alias gcp2p -keyalg RSA -keysize 2048 -validity 10000
    # add signingConfigs to android/app/build.gradle.kts, then:
    gradle -p android assembleRelease

Keep the keystore file and its password safe; if you lose them you cannot update the app.

## Building on a computer
Needs JDK 17, Python 3.12 and Gradle 8.9 (or Android Studio):

    bash android/prepare.sh
    gradle -p android assembleDebug      # APK in android/app/build/outputs/apk/debug/

## If the app shows "Global Chat could not start"
Send the exact text on that screen; it names the Python error.
