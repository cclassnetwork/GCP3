# Architecture

## Modules and how they talk

    +----------------------------- Android app (Java) ---------------------------+
    | MainActivity (WebView) | KeystoreVault | Notifier | P2PService (foreground)  |
    +---------|----------------------|------------^-----------------|------------+
              | Chaquopy: gc_android.start(dataDir, keyHex, notifier) -> "port:token"
    +---------v--------------------------------------------------------------------+
    |  ApiServer (127.0.0.1, token, Host check, CSP)  <--- fetch/SSE ---  Web screens |
    |        |                                                                        |
    |     Engine ── Database (SQLite) ── Identity                                     |
    |        |                                                                        |
    |      Node (connection manager)                                                  |
    |        |-- SecureChannel over TCP link or relay circuit (authenticated, AEAD)   |
    |        |-- Dht            find peers, store signed records, mailbox placement   |
    |        |-- PresenceService signed expiring records, online directory, probes    |
    |        |-- DmService       E2E private messages, mailbox, receipts, retry       |
    |        |-- GroupService    signed gossip + anti-entropy sync                    |
    |        |-- RelayService    circuit relay for peers that cannot accept inbound   |
    |        |-- LanDiscovery    signed UDP beacons on the local Wi-Fi                |
    +--------------------------------------------------------------------------------+

* **Flutter-Python bridge equivalent:** Java starts the engine through Chaquopy and gets back a port and a random
  per-launch token. The UI talks to the engine only through `/api/*` on `127.0.0.1` (JSON requests and a
  Server-Sent-Events stream for live updates). Every request needs the token in `X-GC-Token`; the Host header must be
  loopback (DNS-rebinding guard); bodies are size-limited. The engine never calls back into the UI except the
  Notifier (new-message notification).
* A wire message type (`find_node`, `dm`, `g`, `relay_connect`, ...) is routed by `Node.handlers` to the service that
  owns it. Services call back into `Node` for connections, broadcast, storage and UI events.

## Identity
Ed25519 signing key + X25519 key-agreement key generated on first start. Peer ID = `gc` + base32 of the first 160 bits of SHA-256 of the
signing public key, so it cannot be claimed without the private key. The usernames are free text labels (3-24 chars) stored
in signed presence records; changing one never changes the peer ID. Usernames are **not unique**, so the UI always
shows `name#last4ofPeerID`. The private keys are encrypted at rest with a 32-byte secret that is itself encrypted by
an AES key in the Android Keystore (non-exportable).

## Transport and handshake
TCP between peers (or a relay circuit). Handshake: ephemeral X25519 on both sides, HKDF over the transcript, then each
side proves its Ed25519 identity inside the encrypted channel. Forward secrecy for the transport, mutual
authentication, ChaCha20-Poly1305 for every frame.

## Discovery (DHT)
Kademlia-style: XOR metric, k-buckets (k=16), parallel iterative lookups (alpha=3), 3 replicas. Records are
self-certifying (signed), so storage peers cannot alter them. Bootstrap peers are ordinary peers you add by address;
there is no built-in central bootstrap server. Same-Wi-Fi phones also find each other with signed UDP beacons.

## Presence and the online list
A presence record = peer, username, addresses, timestamp, TTL (180 s), signature. Records spread by gossip and sit
in the DHT. State shown to the user:
* **online**: a live authenticated connection, or a recent successful probe
* **checking**: a fresh record exists, reachability not verified yet
* **unreachable**: fresh record but a probe failed (typically behind NAT with no relay)
* **offline**: no record or it expired

**Limits of global presence.** A decentralised network has no authoritative user list. You see peers whose records
reached you, so a very large network shows a sample, not everyone. "Online" is only as fresh as the TTL and probes.
There is no way to enumerate "all users in the world" without a central index, which this design deliberately lacks.

## Private messages
Per message: fresh ephemeral X25519 key to the recipient's static X25519 key, HKDF, ChaCha20-Poly1305, signed by the
sender. Order of delivery: (1) direct/relayed connection with ACK -> *delivered*; (2) recipient unreachable -> the
sealed envelope is stored on the DHT peers closest to the recipient (mailbox) -> *sent*, and the recipient fetches it
and returns a signed receipt -> *delivered*; (3) retries with exponential back-off for 72 h, then *failed* with a
manual *retry* button. Messages are also queued locally.

**Offline limits.** There is no always-on storage node. Delivery while the recipient is offline works only if some
online peers hold the sealed envelope (max 72 h, 100 per recipient per peer, 5000 per peer). If nobody holds it and
the sender goes offline too, the message waits on the sender's phone. Relay and mailbox peers see ciphertext, the
recipient's ID, size and timing, never the content.

## Global group
Every message: author, unique ID, timestamp, signature. Receivers verify the signature, reject duplicates (ID seen),
reject messages outside the time window (replay), rate-limit per sender, store, and forward to a random subset of
neighbours (fan-out 8, max 8 hops). Anti-entropy sync asks neighbours for messages you lack, so short disconnections
heal. Nobody can post as someone else (signature), but anyone can create new identities, so spam resistance is rate
limits and bans, not identity cost. The group is public by design.

## User-created groups
Any user can create a group (More -> Groups -> Create group). Joining is a **local subscription**: no server keeps a member list.
* **Public group**: announced by an owner-signed record (name, description, owner, id derived from the owner's key) that spreads
  by gossip and by directory sync when peers connect, so it shows under *Discover* on every phone that hears of it. Joining is one
  tap. Messages are signed, **not encrypted**. The owner can close it with a signed tombstone; nobody else can edit or close it.
* **Private group**: never announced. The creator gets an invite code (`gcg1:...`) containing the room key; members paste it to
  join. Messages are ChaCha20-Poly1305 ciphertext under that key and the sender name is inside the ciphertext, so forwarding
  peers see only the sender's peer ID, size and timing. Anyone holding the code can read, and leaving does not revoke it
  (there is no key rotation yet).
* Every peer forwards valid room messages (so a small group still reaches its members across the mesh) but stores only the rooms
  it joined. Leaving deletes the local history. History for a late joiner comes from members' sync, so a group whose members are
  all offline has no history to fetch.
* Limits: 5 owned and 30 joined groups per phone, names 3-40 characters, descriptions up to 120, per-author rate limits.
* Not implemented: per-member bans or admins, key rotation, member lists, unread counters.

## NAT traversal
* Reachability detection: peers report the address they see; if a dialled-back probe works the node is `public`,
  otherwise `private`.
* **Circuit relay (implemented, tested):** a `private` phone keeps an outbound connection to a publicly reachable
  peer and reserves a slot; others reach it through that peer with an end-to-end handshake through the circuit. Relay
  limits: 64 reservations, 128 circuits, 8 MiB and 1 h per circuit.
* **Hole punching: not implemented.** Neither is UPnP/STUN. Two phones both on mobile networks therefore need a
  publicly reachable relay peer.

## Android behaviour
Foreground service keeps the process alive (Android may still kill it under aggressive battery policies: set the app
to *Unrestricted*). Network changes trigger an immediate re-dial. On restart the identity and history load from
SQLite. Notifications are raised by the engine for messages that arrive while the app is not visible; lock-screen
text is hidden. No push service exists, so a fully force-stopped app cannot receive messages until reopened.
